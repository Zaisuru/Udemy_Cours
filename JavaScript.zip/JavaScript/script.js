// // var name ="Thomas";
// // var x= 13
// // var y = 25.63
// // console.log(name)
// // console.log(x)
// // console.log(y)
// // var w = y + x
// // console.log(w)

// // var xToString = x.toString()
// // console.log(xToString)

// // var namelength = name.length;
// // console.log(namelength)

// // var xstring ='12'
// // var xNumeber = parseInt(xstring)
// // console.log(xNumeber)

// // var xstrings ='12.63'
// // var xNumebers = parseFloat(xstrings)
// // console.log(xNumebers)  

// // var MyString = 'Hello World'
// // var position = MyString.indexOf('World')
// // console.log(position)

// // var replace = MyString.replace('Thomas')
// // console.log(replace)

// // var addition = xstring + xstrings
// // console.log(addition)

// // var result = w+y /*fonctionne avec - * / */
// // console.log(result)


// // var a = 6
// // var Boolean = (a===5)
// // console.log(Boolean)

// // var speed=49
// // if (speed<80) {
// //     if (speed<50){
// //         console.log("Tu es en ville ou quoi ?")
// //     }
// //     else{
// //     console.log("Bonne vitesse")
// //     }
// // }
// // else if (speed<100){
// //     console.log("Ralentire")
// // }
// // else{
// //     console.log("Trop vite")
// // }
// // var favoritecolor="Violet"
// // switch(favoritecolor) {
// //     case "Blue":
// //         console.log("c\'est le bleu")
// //         break;
// //     case "Rouge" :
// //         console.log("Espece de satanique")
// //         break;

// //     default:
// //     console.log("c\est noir")
// // }

// // var number=0
// // while(number <20){
// //     console.log(number)
// //     number ++
// // }

// // for (var numbers=0;numbers<5;numbers++)
// // {
// //     console.log(numbers)
// // }


// // function multiplu (number1,number2)
// // {
// //     resulttmulply = number1*number2*number1
// //     return resulttmulply
// // }

// // var c = 5
// // var d = 6

// // var resultat = multiplu(c,d)

// // console.log(resultat)
//-------------------------------------------------------------------------

/* les arrays*/
// var fruits=["Pomme","Banane","Poire","Citron","Orange"]

// // console.log(fruits.length)
// // console.log(fruits)

// fruits.push("Kiwi")
// console.log(fruits)

// fruits.pop()
// console.log(fruits)

// var agrume = fruits.slice(2,4)
// console.log(agrume)
//-------------------------------------------------------------------------
// /* Les Objets*/
// var dog ={
//     name:"Terminator",
//     color :"Blanc",
//     age : 4,
// };

// console.log(dog.age)
// console.log(dog["color"])

// for (var property in dog )
// {
//     console.log(dog[property])
// }

// var cat=new Object();
// cat.name='Penny'
// cat.color='noir'
// cat.age=5

// console.log(cat)

// dog.aboie=function(){console.log("Aboiement")};

// dog.aboie();
//-------------------------------------------------------------------------
/* Fonctions Constructeurs*/

function Dog(nameDog, color, age)
{
    this.name = nameDog ;
    this.color = color;
    this.age = age;
    this.aboie= function()
    {
        console.log("Aboiement" + " " + this.name)
    }
}

var CreateDog =  new Dog('Terminatueur','Blouge',99);
var Dog2 = new Dog('Rex','Rose',2)

console.log(CreateDog)
console.log(Dog2)
CreateDog.aboie();
